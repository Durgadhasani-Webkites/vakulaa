<div class="section-bg partner-bg">
  <div class="container">
    <div class="clearfix">&nbsp;</div>
    <div class="clearfix">&nbsp;</div>
    <div class="clearfix">&nbsp;</div>
    
    <div id="exTab3">	
      <ul  class="nav nav-pills">
       <li class="active">
        <a  href="#1b" data-toggle="tab">India</a>
      </li>
      <li><a href="#2b" data-toggle="tab">Overseas</a>
      </li>
      
    </ul>

    <div class="tab-content clearfix">
     <div class="tab-pane active" id="1b">
      
      <div class="col-lg-6 col-md-6 col-sm-10 col-xs-12 newlogs">
       <div class="newlog">
         <h3>Contact Details</h3><br>
         <form>
           
           <div class="row form-row">

            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <label for="staticEmail" class="col-form-label">Name of Organisation / Company:</label>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
              <input type="text"  class="form-control" id="name" placeholder="Name of Organisation/Company">
            </div>

          </div>
          
          <div class="row form-row">

            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <label for="staticEmail" class="col-form-label">Website:</label>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
              <input type="text"  class="form-control" id="website" placeholder="Website">
            </div>
            
          </div>        
          
          <div class="row form-row">

            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <label for="staticEmail" class="col-form-label">First Name:</label>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
              <input type="text"  class="form-control" id="firstname" placeholder="Enter Your First Name ">
            </div>
            
          </div>

          <div class="row form-row">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <label for="staticEmail" class="col-form-label">Last Name:</label>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
              <input type="text"  class="form-control" id="lastname" placeholder="Enter Your Last Name ">
            </div>
          </div>

          <div class="row form-row">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <label for="staticEmail" class="col-form-label">Email id:</label>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
              <input type="email"  class="form-control" id="email" placeholder=" Enter Your Email id ">
            </div>

          </div>

          <div class="row form-row">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <label for="staticEmail" class="col-form-label">Mobile No:</label>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
              <input type="number"  class="form-control" id="mobnumber" placeholder="Enter Your Mobile No ">
            </div>
          </div>

          
          <div class="row form-row">     
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <label for="staticEmail" class="col-form-label">Telephone No:</label>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
              <input type="number"  class="form-control" id="telnumber" placeholder="Enter Your Telephone No ">
            </div>
          </div>
          
          <div class="row form-row">     
           <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            <label for="staticEmail" class="col-form-label">State:</label>
          </div>
          <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
            <input type="text"  class="form-control" id="state" placeholder="Select State ">
          </div>
        </div>
        
        <div class="row form-row">     
         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
          <label for="staticEmail" class="col-form-label">City:</label>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
          <input type="text"  class="form-control" id="city" placeholder="Select City ">
        </div>
      </div>
      
      <div class="row form-row">     
       <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
        <label for="staticEmail" class="col-form-label">Location:</label>
      </div>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <input type="text"  class="form-control" id="location" placeholder="Location ">
      </div>
    </div>
    
    <div class="row form-row">     
     <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
      <label for="staticEmail" class="col-form-label">Company Address:</label>
    </div>
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
      <input type="text"  class="form-control" id="address" placeholder="Enter You Address ">
    </div>
  </div>
  
  <div class="row form-row">     
   <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
    <label for="staticEmail" class="col-form-label">Pincode:</label>
  </div>
  <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    <input type="number"  class="form-control" id="pincode" placeholder="Enter Your Pincode">
  </div>
</div>

</form>
</div>
</div> 

<div class="col-lg-6 col-md-6 col-sm-10 col-xs-12 newlogs">
  <div class="newlog">
    <h3>Product Details</h3><br>
    <form>
      <div class="form-group row">
        <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col-form-label">Category :</label>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
         <select class="form-control">
           <option value="1">Select Category</option>
           <option value="1">Grocery</option>
           <option value="1">Food</option>
           <option value="1">Fresh Fruits</option>
           
         </select>
       </div>
     </div>

     <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col-form-label">Goods/Services Being Offered :</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <input type="text"  class="form-control" id="name" placeholder="Goods/Services Being Offered  " >
      </div>
    </div>


    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col-form-label">Pan card :</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <input type="number"  class="form-control" id="name" placeholder="Enter Your PAN Numbere ">
      </div>
    </div>

    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col-form-label">GST No :</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <input type="number"  class="form-control" id="name" placeholder=" Enter Your GST  Numbere">
      </div>
    </div>

    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col-form-label">GST Registration Type:</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <input type="number"  class="form-control" id="number" placeholder="Select GST Registration Type ">
      </div>
    </div>

    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col-form-label">Period in Distributorship / Manufacturing /Import:</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <input type="text"  class="form-control" id="text" placeholder="Period in Distributorship / Manufacturing /Import ">
      </div>
    </div>
    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col-form-label">Area Covered:</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <input type="text"  class="form-control" id="name" placeholder="Area Covered ">
      </div>
    </div>
    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col-form-label">Annual Turnover:</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <input type="text"  class="form-control" id="name" placeholder="Annual Turnover">
      </div>
    </div>
    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col-form-label">NMMC Cess No.(If any):</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <input type="text"  class="form-control" id="name" placeholder="NMMC Cess No">
      </div>
    </div>
    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col-form-label">What Products do you do?:</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 form">
        <textarea class="text-area w-input" id="field" maxlength="5000" name="field" placeholder="textarea" required="required"></textarea>
      </div>
    </div>


    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col-form-label">Add One+One:</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 form">
        <input type="number"  class="form-control" id="number" placeholder="Add " > 
      </div>
    </div>


    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12 col-form-label">Validation Code:</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 form">
        <input type="text"  class="form-control" id="name" placeholder="Captcha" > 
      </div>
    </div>
    <div class="Continue">
      <a href="javascript:"> <button type="button" class="btn-nowe">Submit</button></a> 
    </div>
  </form>
</div>
</div>

</div>
<div class="tab-pane" id="2b">
  <div class="col-lg-6 col-md-6 col-sm-10 col-xs-12">
   <div class="newlog">
     <h3>Contact Details</h3><br>
     <form>
       
       
      <div class="form-group row">
        <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Name of Organisation/Company:</label>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
          <input type="text"  class="form-control" id="name" placeholder="Name of Organisation/Company">
        </div>
      </div>
      
      
      <div class="form-group row">
        <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Website:</label>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
          <input type="text"  class="form-control" id="name" placeholder="Website">
        </div>
      </div>

      <div class="form-group row">
        <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">First Name:</label>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
          <input type="text"  class="form-control" id="name" placeholder="Enter Your First Name ">
        </div>
      </div>


      <div class="form-group row">
        <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Last Name:</label>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
          <input type="text"  class="form-control" id="name" placeholder="Enter Your Last Name ">
        </div>
      </div>

      <div class="form-group row">
        <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Email id:</label>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
          <input type="text"  class="form-control" id="name" placeholder=" Enter Your Email id ">
        </div>
      </div>

      <div class="form-group row">
        <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Mobile No:</label>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
          <input type="number"  class="form-control" id="number" placeholder="Enter Your Mobile No ">
        </div>
      </div>
      <div class="form-group row">
        <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Telephone No:</label>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
          <input type="number"  class="form-control" id="number" placeholder="Enter Your Telephone No ">
        </div>
      </div>
      
      <div class="form-group row">
        <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">City:</label>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
          <input type="text"  class="form-control" id="name" placeholder="Select City ">
        </div>
      </div>
      <div class="form-group row">
        <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Location:</label>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
          <input type="text"  class="form-control" id="name" placeholder="Location ">
        </div>
      </div>
      <div class="form-group row">
        <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Company Address:</label>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
          <input type="text"  class="form-control" id="name" placeholder="Enter You Address ">
        </div>
      </div>
      <div class="form-group row">
        <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Pincode:</label>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
          <input type="text"  class="form-control" id="name" placeholder="Enter Your Pincode">
        </div>
      </div>
    </form>
  </div>
</div> 

<div class="col-lg-6 col-md-6 col-sm-10 col-xs-12">
  <div class="newlog">
    <h3>Product Details</h3><br>
    <form>
      <div class="form-group row">
        <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Category :</label>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
          <select class="form-control">
           <option value="1">Select Category</option>
           <option value="1">Grocery</option>
           <option value="1">Food</option>
           <option value="1">Fresh Fruits</option>
           
         </select>
       </div>
     </div>

     <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Goods/Services Being Offered :</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <input type="text"  class="form-control" id="name" placeholder="Goods/Services Being Offered  " >
      </div>
    </div>


    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Period in Distributorship / Manufacturing /Import:</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <input type="number"  class="form-control" id="number" placeholder="Enter Your Telephone No ">
      </div>
    </div>
    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Area Covered:</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <input type="text"  class="form-control" id="name" placeholder="Area Covered ">
      </div>
    </div>
    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Annual Turnover:</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <input type="text"  class="form-control" id="name" placeholder="Annual Turnover">
      </div>
    </div>
    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">NMMC Cess No. (If any) :</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <input type="text"  class="form-control" id="name" placeholder="NMMC Cess No">
      </div>
    </div>
    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">What Products do you do?:</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 form">
        <textarea class="text-area w-input" id="field" maxlength="5000" name="field" placeholder="textarea" required="required"></textarea>
      </div>
    </div>

    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Add One+One:</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 form">
        <input type="number"  class="form-control" id="name" placeholder="Add " > 
      </div>
    </div>

    <div class="form-group row">
      <label for="staticEmail" class="col-lg-4 col-md-4 col-sm-4 col-xs-12  col-form-label">Validation Code:</label>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 form">
        <input type="text"  class="form-control" id="name" placeholder="Captcha" > 
      </div>
    </div>
    <div class="Continue">
      <a href="javascript:"> <button type="button" class="btn-nowe">Submit</button></a> 
    </div>
  </form>
</div>
</div>
</div>
<div class="tab-pane" id="3b">
  <h3>India</h3>
</div>
<div class="tab-pane" id="4b">
  <h3>Overseas</h3>
</div>
</div>
</div>

</div>
</div>

<div class="clearfix">&nbsp;</div>
<div class="clearfix">&nbsp;</div>
<div class="clearfix visible-xs">&nbsp;</div>
