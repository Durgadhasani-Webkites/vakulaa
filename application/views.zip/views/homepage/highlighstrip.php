<div class="container hidden-sm hidden-xs">
        <img src="<?php echo $this->config->item('user_images'); ?>organic_and_eco_products.jpg" alt="Online organic store Chennai" title="Online organic store Chennai">
    </div>
    <div class="clearfix">&nbsp;</div>  <div class="clearfix">&nbsp;</div>