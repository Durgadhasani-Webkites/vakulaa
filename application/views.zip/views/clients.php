<section class="clients">
    <div class="section-bg">
           <div class="container">
            <div class="clearfix">&nbsp;</div>
            <div class="clearfix">&nbsp;</div>
            <div class="clearfix">&nbsp;</div>
 


    <div class="row">

    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
        <div class="clients-logo">
         <a href="javascript:" title="products">
            <img src="<?php echo $this->config->item('user_images'); ?>nissan.png" alt="products" class="img-responsive">
        </a>
        </div>
    </div>

      <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
         <div class="clients-logo">
            <a href="javascript:" title="products">
             <img src="<?php echo $this->config->item('user_images'); ?>meatandeat.png" alt="products" class="img-responsive">
            </a>
        </div>
    </div>

     <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
        <div class="clients-logo">
            <a href="javascript:" title="products">
              <img src="<?php echo $this->config->item('user_images'); ?>a1-01.png" alt="products" class="img-responsive">
            </a>
    </div>
     </div>

        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
           <div class="clients-logo">
            <a href="javascript:" title="products">
                <img src="<?php echo $this->config->item('user_images'); ?>vakullaa.png" alt="products" class="img-responsive">
                </a>
            </div>
        </div>

    </div> 

    <div class="clearfix">&nbsp;</div>

        <div class="row">

                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                <div class="clients-logo">
                    <a href="javascript:" title="products">
                        <img src="<?php echo $this->config->item('user_images'); ?>drdo-01.png" alt="products" class="img-responsive">
                        </a>
                    </div>
                </div>   

                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                <div class="clients-logo  ">
                    <a href="javascript:" title="products">
                        <img src="<?php echo $this->config->item('user_images'); ?>clientlogo-01.png" alt="products" class="img-responsive">
                        </a>
                    </div>
                </div>   
                        
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                <div class="clients-logo ">
                    <a href="javascript:" title="products">
                        <img src="<?php echo $this->config->item('user_images'); ?>chef.png" alt="products" class="img-responsive">
                        </a>
                    </div>
                </div> 

                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                <div class="clients-logo ">
                    <a href="javascript:" title="products">
                        <img src="<?php echo $this->config->item('user_images'); ?>reliance.png" alt="products" class="img-responsive">
                        </a>
                    </div>
                </div>    
        
           </div>
           </div>
          </div>
    </section>
    <div class="clearfix">&nbsp;</div>
    <div class="clearfix">&nbsp;</div>
